
//apenas para testar o tratamento de exceções
public class Conta {

    void deposita() {}

}
